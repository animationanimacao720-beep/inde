package com.dev.codeinjector

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.PendingIntent
import android.os.Build
import androidx.core.content.ContextCompat
import java.util.Base64
import java.util.concurrent.atomic.AtomicInteger

/** Executa código no Termux via intent RUN_COMMAND e devolve stdout/stderr pelo PendingIntent. */
object TermuxRunner {
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    private const val PREFIX = "/data/data/com.termux/files/usr"
    private const val HOME = "/data/data/com.termux/files/home"
    private val counter = AtomicInteger(1)
    @Volatile var callback: ((String) -> Unit)? = null

    const val SETUP_COMMANDS =
        "mkdir -p ~/.termux; grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null || " +
        "echo 'allow-external-apps=true' >> ~/.termux/termux.properties; termux-reload-settings; " +
        "pkg install -y python clang openjdk-17 kotlin"

    const val GUI_SETUP =
        "pkg install -y x11-repo && pkg install -y termux-x11-nightly python-tkinter sdl2 fltk"

    fun isX11Installed(ctx: Context) = runCatching { ctx.packageManager.getPackageInfo("com.termux.x11", 0) }.isSuccess

    /** Abre o app Termux:X11 (depois de dar um tempo para o servidor subir). */
    fun openX11(ctx: Context) {
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            ctx.packageManager.getLaunchIntentForPackage("com.termux.x11")?.let {
                ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }, 1800)
    }

    fun isInstalled(ctx: Context) = runCatching { ctx.packageManager.getPackageInfo("com.termux", 0) }.isSuccess
    fun hasPermission(ctx: Context) = ContextCompat.checkSelfPermission(ctx, PERMISSION) == PackageManager.PERMISSION_GRANTED

    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray())

    private fun script(lang: Language, code: String, stdin: String, gui: Boolean): String? {
        val ext = when (lang) { Language.PYTHON -> "py"; Language.KOTLIN -> "kt"; Language.CPP -> "cpp"; else -> return null }
        val flags = if (gui && lang == Language.CPP) when {
            code.contains("SDL") -> "\$(sdl2-config --cflags --libs)"
            code.contains("<FL/") -> "\$(fltk-config --cxxflags --ldflags)"
            else -> ""
        } else ""
        val run = when (lang) {
            Language.PYTHON -> if (gui) "python main.py" else "timeout 60 python main.py < in.txt"
            Language.CPP -> "clang++ -O1 -o main main.cpp $flags && " + (if (gui) "./main" else "timeout 60 ./main < in.txt")
            Language.KOTLIN -> "kotlinc main.kt -include-runtime -d main.jar && timeout 60 java -jar main.jar < in.txt"
            else -> return null
        }
        if (gui && lang == Language.PYTHON && Regex("(?m)^\\s*(from|import)\\s+kivy").containsMatchIn(code)) {
            // Kivy roda dentro do Debian (proot-distro) com o venv ~/kv
            val root = "$PREFIX/var/lib/proot-distro/installed-rootfs/debian/root"
            return "{ (nohup termux-x11 :0 >/dev/null 2>&1 &); sleep 2; } && mkdir -p $root/.ci && " +
                "printf %s '${b64(code)}' | base64 -d > $root/.ci/main.py && " +
                "proot-distro login debian --shared-tmp -- bash -c '. ~/kv/bin/activate && " +
                "export DISPLAY=:0 LIBGL_ALWAYS_SOFTWARE=1 KIVY_NO_ARGS=1 && python ~/.ci/main.py'"
        }
        val x = if (gui) "{ (nohup termux-x11 :0 >/dev/null 2>&1 &); sleep 2; export DISPLAY=:0 LIBGL_ALWAYS_SOFTWARE=1 KIVY_NO_ARGS=1; } && " else ""
        return "mkdir -p ~/.ci && cd ~/.ci && printf %s '${b64(code)}' | base64 -d > main.$ext && " +
            "printf %s '${b64(stdin)}' | base64 -d > in.txt && $x$run"
    }

    fun run(ctx: Context, lang: Language, code: String, stdin: String, gui: Boolean = false, onResult: (String) -> Unit) {
        val sh = script(lang, code, stdin, gui)
        if (sh == null) { onResult("Este tipo de arquivo não é executável."); return }
        callback = onResult
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(
            ctx, counter.getAndIncrement(), Intent(ctx, TermuxResultReceiver::class.java), flags
        )
        val i = Intent("com.termux.RUN_COMMAND").apply {
            setClassName("com.termux", "com.termux.app.RunCommandService")
            putExtra("com.termux.RUN_COMMAND_PATH", "$PREFIX/bin/bash")
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", sh))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        } catch (e: Exception) {
            callback = null
            onResult("[erro ao chamar o Termux] ${e.message}\nConfira a permissão \"Executar comandos no Termux\" e allow-external-apps=true.")
        }
    }
}

class TermuxResultReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val b = i.getBundleExtra("result")
        val sb = StringBuilder()
        if (b == null) sb.append("[sem resultado do Termux]")
        else {
            b.getString("stdout")?.takeIf { it.isNotBlank() }?.let { sb.append(it.trimEnd()).append('\n') }
            b.getString("stderr")
                ?.lines()?.filterNot {
                    it.contains("jansi", true) || it.contains("proot warning") || it.startsWith("osinfo:") || it.contains("UnsatisfiedLinkError") ||
                        Regex("^\\s+at ").containsMatchIn(it) || Regex("^\\s*\\.\\.\\. \\d+ more").containsMatchIn(it)
                }
                ?.joinToString("\n")?.takeIf { it.isNotBlank() }
                ?.let { sb.append("[stderr]\n").append(it.trimEnd()).append('\n') }
            b.getString("errmsg")?.takeIf { it.isNotBlank() }?.let {
                sb.append("[erro do Termux] ").append(it).append("\n(confira allow-external-apps=true e se os pacotes estão instalados)\n")
            }
            if (b.containsKey("exitCode")) sb.append("— código de saída ${b.getInt("exitCode")}")
        }
        TermuxRunner.callback?.invoke(sb.toString().trimEnd())
        TermuxRunner.callback = null
    }
}
