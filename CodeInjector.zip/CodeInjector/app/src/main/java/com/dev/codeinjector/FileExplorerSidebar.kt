package com.dev.codeinjector

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Estado do explorador: pasta raiz escolhida (SAF), pilha de navegação, filtro. Persistido em SharedPreferences. */
class ProjectExplorerState(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("project", Context.MODE_PRIVATE)
    var treeUri by mutableStateOf(prefs.getString("tree", null)?.let { Uri.parse(it) })
        private set
    val stack = mutableStateListOf<Pair<String, String>>()   // (documentId, nome)
    var entries by mutableStateOf<List<DocEntry>>(emptyList())
    var loading by mutableStateOf(false)
    var refreshTick by mutableIntStateOf(0)
    var showAll by mutableStateOf(prefs.getBoolean("showAll", false))
        private set

    init {
        val id = treeUri?.let { u -> runCatching { DocumentsContract.getTreeDocumentId(u) }.getOrNull() }
        if (id != null) stack.add(id to (prefs.getString("name", null) ?: "Projeto"))
    }

    val currentDirId: String? get() = stack.lastOrNull()?.first

    fun setRoot(uri: Uri, name: String) {
        val id = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull() ?: return
        treeUri = uri; stack.clear(); stack.add(id to name)
        prefs.edit().putString("tree", uri.toString()).putString("name", name).apply()
    }

    fun toggleShowAll() { showAll = !showAll; prefs.edit().putBoolean("showAll", showAll).apply() }
    fun refresh() { refreshTick++ }
}

private val HIDDEN_DIRS = setOf("__pycache__", ".git", ".idea", ".venv", "venv", "node_modules", ".gradle", "build")

private sealed interface Dlg {
    data class Create(val dir: Boolean) : Dlg
    data class Rename(val e: DocEntry) : Dlg
    data class Delete(val e: DocEntry) : Dlg
    data class Move(val e: DocEntry) : Dlg
}

/**
 * Painel lateral dedicado a projetos Python: mostra pastas e arquivos .py (alterne para ver tudo),
 * toque abre em nova aba; toque longo = renomear / mover / excluir.
 * [onDocChanged] avisa que um documento mudou de id (renomear/mover) ou foi excluído (newId == null),
 * para as abas abertas atualizarem o Uri.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileExplorerSidebar(
    state: ProjectExplorerState, theme: CodeTheme, activeUri: Uri?,
    onPickFolder: () -> Unit,
    onOpenFile: (DocEntry) -> Unit,
    onDocChanged: (oldId: String, newId: String?) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val tree = state.treeUri
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    LaunchedEffect(tree, state.currentDirId, state.refreshTick) {
        val d = state.currentDirId
        if (tree == null || d == null) { state.entries = emptyList(); return@LaunchedEffect }
        state.loading = true
        state.entries = withContext(Dispatchers.IO) { ProjectFs.list(ctx, tree, d) }
        state.loading = false
    }
    val visible = state.entries.filter {
        if (it.isDir) it.name !in HIDDEN_DIRS else state.showAll || it.name.endsWith(".py")
    }
    val activeId = activeUri?.let { runCatching { DocumentsContract.getDocumentId(it) }.getOrNull() }

    Column(modifier.background(theme.bar)) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(state.stack.joinToString(" / ") { it.second }.ifEmpty { "Sem pasta" }, Modifier.weight(1f),
                color = theme.text, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            TextButton(onClose) { Text("✕", color = theme.text) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            SideBtn("＋ .py", theme) { if (tree != null) dlg = Dlg.Create(false) else onPickFolder() }
            SideBtn("＋ pasta", theme) { if (tree != null) dlg = Dlg.Create(true) else onPickFolder() }
            SideBtn("↻", theme) { state.refresh() }
            SideBtn(if (state.showAll) "Tudo" else "Só .py", theme) { state.toggleShowAll() }
            SideBtn("Trocar", theme) { onPickFolder() }
        }
        if (tree == null) {
            Text("Escolha a pasta do projeto Python (no seletor, abra o menu lateral e procure o CodeAssist ou o armazenamento).",
                Modifier.padding(12.dp), color = theme.comment, fontSize = 13.sp)
            TextButton(onPickFolder, Modifier.padding(horizontal = 4.dp)) { Text("Abrir pasta do projeto", color = theme.function) }
        } else LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (state.stack.size > 1) item {
                Text("📁  .. (voltar)", Modifier.fillMaxWidth().combinedClickable(onClick = { state.stack.removeAt(state.stack.lastIndex) }).padding(12.dp),
                    color = theme.text, fontSize = 14.sp)
            }
            if (!state.loading && visible.isEmpty()) item {
                Text("Nenhum arquivo .py aqui.", Modifier.padding(12.dp), color = theme.comment, fontSize = 12.sp)
            }
            items(visible, key = { it.id }) { e ->
                Box {
                    val icon = if (e.isDir) "📁" else if (e.name.endsWith(".py")) "🐍" else "📄"
                    Text("$icon  ${e.name}",
                        Modifier.fillMaxWidth()
                            .background(if (e.id == activeId) theme.chip else Color.Transparent)
                            .combinedClickable(
                                onClick = { if (e.isDir) state.stack.add(e.id to e.name) else onOpenFile(e) },
                                onLongClick = { menuFor = e.id }
                            ).padding(horizontal = 12.dp, vertical = 11.dp),
                        color = theme.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    DropdownMenu(expanded = menuFor == e.id, onDismissRequest = { menuFor = null }) {
                        DropdownMenuItem(text = { Text("Renomear") }, onClick = { menuFor = null; dlg = Dlg.Rename(e) })
                        DropdownMenuItem(text = { Text("Mover para…") }, onClick = { menuFor = null; dlg = Dlg.Move(e) })
                        DropdownMenuItem(text = { Text("Excluir") }, onClick = { menuFor = null; dlg = Dlg.Delete(e) })
                    }
                }
            }
        }
    }

    when (val d = dlg) {
        is Dlg.Create -> NameDialog(
            title = if (d.dir) "Nova pasta" else "Novo arquivo Python", initial = "", onDismiss = { dlg = null }
        ) { raw ->
            var n = raw.trim()
            if (tree == null || state.currentDirId == null || n.isEmpty() || '/' in n) { toast("Nome inválido (não use '/')"); return@NameDialog }
            if (!d.dir && '.' !in n) n += ".py"
            val uri = ProjectFs.create(ctx, tree, state.currentDirId!!, n, d.dir)
            if (uri == null) toast("Não consegui criar \"$n\"")
            else {
                dlg = null; state.refresh()
                if (!d.dir) onOpenFile(DocEntry(DocumentsContract.getDocumentId(uri), n, false))
            }
        }
        is Dlg.Rename -> NameDialog("Renomear", d.e.name, { dlg = null }) { raw ->
            var n = raw.trim()
            if (tree == null || n.isEmpty() || '/' in n) { toast("Nome inválido"); return@NameDialog }
            if (!d.e.isDir && '.' !in n && d.e.name.endsWith(".py")) n += ".py"
            val newId = ProjectFs.rename(ctx, tree, d.e.id, n)
            if (newId == null) toast("O provedor de arquivos recusou renomear")
            else { dlg = null; onDocChanged(d.e.id, newId); state.refresh() }
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Excluir \"${d.e.name}\"?") },
            text = { Text(if (d.e.isDir) "A pasta e tudo que está dentro serão apagados." else "Esta ação não pode ser desfeita.") },
            confirmButton = {
                TextButton({
                    if (tree != null && ProjectFs.delete(ctx, tree, d.e.id)) { onDocChanged(d.e.id, null); state.refresh() } else toast("Não consegui excluir")
                    dlg = null
                }) { Text("Excluir") }
            },
            dismissButton = { TextButton({ dlg = null }) { Text("Cancelar") } }
        )
        is Dlg.Move -> if (tree != null) FolderPicker(
            ctx = ctx, tree = tree, root = state.stack.first(), moving = d.e,
            onDismiss = { dlg = null },
            onPick = { targetId ->
                val from = state.currentDirId
                val newId = if (from != null) ProjectFs.move(ctx, tree, d.e.id, from, targetId) else null
                if (newId == null) toast("Não consegui mover") else { onDocChanged(d.e.id, newId); state.refresh() }
                dlg = null
            }
        )
        null -> {}
    }
}

@Composable
private fun SideBtn(label: String, theme: CodeTheme, onClick: () -> Unit) =
    TextButton(onClick, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
        Text(label, fontSize = 12.sp, color = theme.function)
    }

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, label = { Text("Nome (ex.: utils.py)") }) },
        confirmButton = { TextButton({ onOk(v) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

/** Escolhe a pasta de destino navegando só entre diretórios. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderPicker(
    ctx: Context, tree: Uri, root: Pair<String, String>, moving: DocEntry,
    onDismiss: () -> Unit, onPick: (String) -> Unit
) {
    val stack = remember { mutableStateListOf(root) }
    var dirs by remember { mutableStateOf<List<DocEntry>>(emptyList()) }
    val cur = stack.last()
    LaunchedEffect(cur.first) {
        dirs = withContext(Dispatchers.IO) { ProjectFs.list(ctx, tree, cur.first).filter { it.isDir && it.name !in HIDDEN_DIRS } }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mover \"${moving.name}\" para", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.heightIn(max = 320.dp)) {
                Text(stack.joinToString(" / ") { it.second }, fontSize = 12.sp)
                LazyColumn(Modifier.fillMaxWidth()) {
                    if (stack.size > 1) item {
                        Text("📁  .. (voltar)", Modifier.fillMaxWidth().combinedClickable(onClick = { stack.removeAt(stack.lastIndex) }).padding(10.dp))
                    }
                    items(dirs.filter { it.id != moving.id }, key = { it.id }) { d ->
                        Text("📁  ${d.name}", Modifier.fillMaxWidth().combinedClickable(onClick = { stack.add(d.id to d.name) }).padding(10.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton({ onPick(cur.first) }) { Text("Mover aqui") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}
