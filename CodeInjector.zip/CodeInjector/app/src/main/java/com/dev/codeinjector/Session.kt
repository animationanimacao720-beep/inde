package com.dev.codeinjector

import android.content.Context
import android.net.Uri
import androidx.compose.ui.text.TextRange
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Retrato de uma aba, comparável por igualdade (usado para detectar mudanças e salvar). */
data class SessionTab(
    val id: Int, val name: String, val uri: String?,
    val dirty: Boolean, val text: String, val s: Int, val e: Int
)

fun EditorTab.toSession() = SessionTab(
    id, name, uri?.toString(), dirty, value.text, value.selection.start, value.selection.end
)

/**
 * Guarda as abas abertas em filesDir/session.json para sobreviver à recriação da Activity
 * e à morte do processo.
 */
class SessionStore(ctx: Context) {
    private val file = File(ctx.filesDir, "session.json")
    private val tmp = File(ctx.filesDir, "session.json.tmp")

    class Restored(val tabs: List<EditorTab>, val cur: Int, val nextId: Int)

    fun save(tabs: List<SessionTab>, cur: Int, nextId: Int) {
        runCatching {
            val arr = JSONArray()
            tabs.forEach { t ->
                arr.put(
                    JSONObject().put("id", t.id).put("name", t.name)
                        .put("uri", t.uri ?: JSONObject.NULL)
                        .put("dirty", t.dirty).put("text", t.text).put("s", t.s).put("e", t.e)
                )
            }
            tmp.writeText(JSONObject().put("cur", cur).put("nextId", nextId).put("tabs", arr).toString())
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
        }
    }

    private fun root(): JSONObject? = runCatching {
        if (file.exists()) JSONObject(file.readText()) else null
    }.getOrNull()

    fun load(): Restored? = runCatching {
        val r = root() ?: return@runCatching null
        val a = r.getJSONArray("tabs")
        val list = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val uri = if (o.isNull("uri")) null else Uri.parse(o.getString("uri"))
            EditorTab(o.getInt("id"), o.getString("name"), uri, o.getString("text")).also { t ->
                val len = t.value.text.length
                t.value = t.value.copy(
                    selection = TextRange(o.optInt("s").coerceIn(0, len), o.optInt("e").coerceIn(0, len))
                )
                t.dirty = o.optBoolean("dirty")
            }
        }
        if (list.isEmpty()) null
        else Restored(list, r.optInt("cur").coerceIn(0, list.lastIndex), maxOf(r.optInt("nextId"), list.maxOf { it.id } + 1))
    }.getOrNull()
}
