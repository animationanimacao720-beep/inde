package com.dev.codeinjector

import android.content.Context
import android.os.Process
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors
import kotlin.concurrent.thread

enum class StreamKind { OUT, ERR, IN, SYS }
data class ConsoleChunk(val kind: StreamKind, val text: String)
enum class RunState { IDLE, STARTING, RUNNING, WAITING_INPUT, STOPPING }

/** Erro de execução (traceback) do último script. [sourceHash] liga o erro ao texto que foi executado. */
data class PyRuntimeError(
    val type: String, val message: String, val line: Int, val col: Int,
    val suggestion: String, val fileName: String, val sourceHash: Int
)

/** Interface chamada pelo Python (ci_runner.py). Os nomes dos métodos precisam bater com o módulo. */
interface PySink {
    fun write(stream: String, text: String)
    fun onInputRequested(prompt: String)
    fun onInputConsumed()
    fun onException(type: String, message: String, line: Int, col: Int, suggestion: String)
}

/**
 * CPython nativo (Chaquopy). Executa um script por vez numa thread dedicada, com:
 *  - stdout/stderr em tempo real (chunks agrupados a cada ~30 ms, limite de memória),
 *  - input()/sys.stdin interativos ([sendInput] / [sendEof]),
 *  - parada imediata ([stop]) e, em último caso, [forceKill].
 */
object PyRunner : PySink {
    private const val MODULE = "ci_runner"
    private const val MAX_CHARS = 100_000

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val ctl = Executors.newSingleThreadExecutor { r -> Thread(r, "py-ctl").apply { isDaemon = true } }.asCoroutineDispatcher()
    private val outCh = Channel<ConsoleChunk>(Channel.UNLIMITED)

    private val _chunks = MutableStateFlow<List<ConsoleChunk>>(emptyList())
    val chunks: StateFlow<List<ConsoleChunk>> = _chunks.asStateFlow()
    private val _state = MutableStateFlow(RunState.IDLE)
    val state: StateFlow<RunState> = _state.asStateFlow()
    private val _prompt = MutableStateFlow<String?>(null)
    /** Não nulo enquanto o script espera por input() (contém o texto do prompt). */
    val prompt: StateFlow<String?> = _prompt.asStateFlow()
    private val _error = MutableStateFlow<PyRuntimeError?>(null)
    val error: StateFlow<PyRuntimeError?> = _error.asStateFlow()
    private val _stuck = MutableStateFlow(false)
    /** true quando o Stop não conseguiu encerrar o script (ex.: preso em código nativo). */
    val stuck: StateFlow<Boolean> = _stuck.asStateFlow()

    @Volatile private var runFile = ""
    @Volatile private var runHash = 0
    @Volatile private var stopRequested = false
    private var written = emptySet<String>()

    init {
        scope.launch {
            for (first in outCh) {
                val batch = ArrayList<ConsoleChunk>()
                batch += first
                delay(30)
                while (true) batch += (outCh.tryReceive().getOrNull() ?: break)
                _chunks.update { merge(it, batch) }
            }
        }
    }

    private fun merge(old: List<ConsoleChunk>, add: List<ConsoleChunk>): List<ConsoleChunk> {
        val out = ArrayList<ConsoleChunk>(old.size + add.size)
        out.addAll(old)
        for (c in add) {
            val last = out.lastOrNull()
            if (last != null && last.kind == c.kind) out[out.lastIndex] = last.copy(text = last.text + c.text) else out += c
        }
        var total = out.sumOf { it.text.length }
        while (total > MAX_CHARS && out.size > 1) total -= out.removeAt(0).text.length
        if (total > MAX_CHARS) out[0] = out[0].copy(text = out[0].text.takeLast(MAX_CHARS))
        return out
    }

    fun clearConsole() { _chunks.value = emptyList() }

    private fun emit(kind: StreamKind, text: String) { outCh.trySend(ConsoleChunk(kind, text)) }

    // ---------------------------------------------------------------- PySink (chamado pelo Python)
    override fun write(stream: String, text: String) = emit(if (stream == "err") StreamKind.ERR else StreamKind.OUT, text)

    override fun onInputRequested(prompt: String) {
        _prompt.value = prompt
        if (_state.value == RunState.RUNNING) _state.value = RunState.WAITING_INPUT
    }

    override fun onInputConsumed() {
        _prompt.value = null
        if (_state.value == RunState.WAITING_INPUT) _state.value = RunState.RUNNING
    }

    override fun onException(type: String, message: String, line: Int, col: Int, suggestion: String) {
        _error.value = PyRuntimeError(type, message, line, col, suggestion, runFile, runHash)
    }

    // ---------------------------------------------------------------- ciclo de vida
    @Synchronized
    fun ensureStarted(ctx: Context) {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx.applicationContext))
    }

    /** Inicializa o interpretador em segundo plano (chame ao abrir o app). */
    fun warmUp(ctx: Context) { scope.launch { runCatching { ensureStarted(ctx) } } }

    fun workDir(ctx: Context) = File(ctx.filesDir, "py_workspace").also { it.mkdirs() }

    private fun module() = Python.getInstance().getModule(MODULE)

    /**
     * Executa [source]. [siblings] (nome -> texto) são gravados no diretório de trabalho para que
     * `import outro_arquivo` funcione entre as abas abertas.
     */
    fun run(ctx: Context, source: String, fileName: String, siblings: Map<String, String> = emptyMap()) {
        if (_state.value != RunState.IDLE) return
        _state.value = RunState.STARTING
        stopRequested = false
        _chunks.value = emptyList(); _error.value = null; _prompt.value = null; _stuck.value = false
        runFile = fileName; runHash = source.hashCode()
        val app = ctx.applicationContext
        thread(name = "py-run", isDaemon = true) {
            var code = -1
            try {
                ensureStarted(app)
                val work = workDir(app)
                val names = HashSet<String>()
                siblings.forEach { (n, t) ->
                    if (n.endsWith(".py") && '/' !in n && n != "$MODULE.py") {
                        runCatching { File(work, n).writeText(t); names += n }
                    }
                }
                (written - names).forEach { File(work, it).delete() }
                written = names
                if (!stopRequested) {
                    _state.value = RunState.RUNNING
                    code = module().callAttr("run", source, fileName, this@PyRunner, work.absolutePath).toInt()
                }
            } catch (e: Throwable) {
                emit(StreamKind.ERR, "[erro interno] ${e.message}\n")
            } finally {
                _prompt.value = null
                emit(StreamKind.SYS, if (code == 130 || stopRequested) "\n[processo interrompido]\n" else "\n[processo finalizado com código $code]\n")
                _state.value = RunState.IDLE
                _stuck.value = false
            }
        }
    }

    /** Envia uma linha para o input() em espera (ecoa no console). */
    fun sendInput(line: String) {
        if (_prompt.value == null) return
        emit(StreamKind.IN, line + "\n")
        _prompt.value = null
        if (_state.value == RunState.WAITING_INPUT) _state.value = RunState.RUNNING
        scope.launch(ctl) { runCatching { module().callAttr("provide_input", line) } }
    }

    /** Equivale a Ctrl+D: encerra a entrada padrão. */
    fun sendEof() {
        if (_prompt.value == null) return
        emit(StreamKind.IN, "^D\n")
        _prompt.value = null
        scope.launch(ctl) { runCatching { module().callAttr("provide_eof") } }
    }

    /** Interrompe o script: reenvia KeyboardInterrupt a cada 250 ms por até 3 s (o código do usuário pode capturá-lo). */
    fun stop() {
        val s = _state.value
        if (s == RunState.IDLE || s == RunState.STOPPING) return
        stopRequested = true
        _state.value = RunState.STOPPING
        if (s == RunState.STARTING) return
        scope.launch(ctl) {
            repeat(12) {
                if (_state.value == RunState.IDLE) return@launch
                runCatching { module().callAttr("stop") }
                delay(250)
            }
            if (_state.value != RunState.IDLE) {
                emit(StreamKind.SYS, "\n[o script não respondeu ao Stop — use \"Forçar encerramento\"]\n")
                _stuck.value = true
            }
        }
    }

    /** Último recurso: encerra o processo do app (o Python roda in-process). Reabra o app depois. */
    fun forceKill() { Process.killProcess(Process.myPid()) }

    // ---------------------------------------------------------------- análise
    /** Verificação com o parser real do CPython. Retorna null se o interpretador ainda não iniciou. */
    fun check(source: String, fileName: String = "<editor>"): List<PyIssue>? = runCatching {
        if (!Python.isStarted()) return null
        val arr = JSONArray(module().callAttr("check", source, fileName).toString())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            PyIssue(
                o.getString("kind"), o.getString("type"), o.getString("msg"),
                o.getInt("line"), o.getInt("col"), o.getInt("end_line"), o.getInt("end_col"),
                o.optString("suggest")
            )
        }
    }.getOrNull()
}
