package com.dev.codeinjector

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

// ============================================================ temas
data class CodeTheme(
    val name: String,
    val bg: Color, val bar: Color, val gutterBg: Color, val gutterText: Color, val gutterActive: Color,
    val text: Color, val cursor: Color,
    val keyword: Color, val builtin: Color, val string: Color, val comment: Color, val number: Color,
    val function: Color, val className: Color, val decorator: Color, val self: Color,
    val error: Color, val chip: Color
)

object CodeThemes {
    val Dracula = CodeTheme(
        "Dracula", Color(0xFF282A36), Color(0xFF21222C), Color(0xFF242530), Color(0xFF6272A4), Color(0xFFF8F8F2),
        Color(0xFFF8F8F2), Color(0xFFF8F8F0),
        Color(0xFFFF79C6), Color(0xFF8BE9FD), Color(0xFFF1FA8C), Color(0xFF6272A4), Color(0xFFBD93F9),
        Color(0xFF50FA7B), Color(0xFF8BE9FD), Color(0xFF50FA7B), Color(0xFFFFB86C),
        Color(0xFFFF5555), Color(0xFF44475A)
    )
    val Monokai = CodeTheme(
        "Monokai", Color(0xFF272822), Color(0xFF1E1F1C), Color(0xFF23241F), Color(0xFF75715E), Color(0xFFF8F8F2),
        Color(0xFFF8F8F2), Color(0xFFF8F8F0),
        Color(0xFFF92672), Color(0xFF66D9EF), Color(0xFFE6DB74), Color(0xFF75715E), Color(0xFFAE81FF),
        Color(0xFFA6E22E), Color(0xFFA6E22E), Color(0xFFA6E22E), Color(0xFFFD971F),
        Color(0xFFFF4D4D), Color(0xFF3E3D32)
    )
    val GitHubDark = CodeTheme(
        "GitHub Dark", Color(0xFF0D1117), Color(0xFF161B22), Color(0xFF0D1117), Color(0xFF6E7681), Color(0xFFE6EDF3),
        Color(0xFFC9D1D9), Color(0xFFC9D1D9),
        Color(0xFFFF7B72), Color(0xFF79C0FF), Color(0xFFA5D6FF), Color(0xFF8B949E), Color(0xFF79C0FF),
        Color(0xFFD2A8FF), Color(0xFFFFA657), Color(0xFFD2A8FF), Color(0xFFFFA657),
        Color(0xFFF85149), Color(0xFF21262D)
    )
    val all = listOf(Dracula, Monokai, GitHubDark)
}

// ============================================================ abas
class EditorTab(val id: Int, name: String, uri: Uri? = null, text: String = "") {
    var name by mutableStateOf(name)
    var uri by mutableStateOf(uri)
    var value by mutableStateOf(TextFieldValue(text))
    var dirty by mutableStateOf(false)
    private val undoStack = ArrayDeque<TextFieldValue>()
    private val redoStack = ArrayDeque<TextFieldValue>()
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)

    private fun sync() { undoCount = undoStack.size; redoCount = redoStack.size }

    fun change(nv: TextFieldValue) {
        if (nv.text != value.text) {
            undoStack.addLast(value); if (undoStack.size > 200) undoStack.removeFirst()
            redoStack.clear(); dirty = true; sync()
        }
        value = nv
    }
    fun undo() { undoStack.removeLastOrNull()?.let { redoStack.addLast(value); value = it; dirty = true; sync() } }
    fun redo() { redoStack.removeLastOrNull()?.let { undoStack.addLast(value); value = it; dirty = true; sync() } }
}

class SnippetStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("snippets", Context.MODE_PRIVATE)
    fun load(): List<Pair<String, String>> {
        val a = JSONArray(p.getString("l", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("n") to o.getString("b") } }
    }
    fun save(list: List<Pair<String, String>>) {
        val a = JSONArray(); list.forEach { a.put(JSONObject().put("n", it.first).put("b", it.second)) }
        p.edit().putString("l", a.toString()).apply()
    }
}

private fun displayNameOrNull(ctx: Context, uri: Uri): String? = runCatching {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}.getOrNull()

private fun displayName(ctx: Context, uri: Uri) = displayNameOrNull(ctx, uri) ?: "arquivo.py"

// ============================================================ fontes (JetBrains Mono / Fira Code via assets/fonts)
private fun loadAssetFamily(ctx: Context, file: String): FontFamily? {
    val ok = runCatching { ctx.assets.list("fonts")?.contains(file) == true }.getOrDefault(false)
    if (!ok) return null
    return runCatching { FontFamily(Font("fonts/$file", ctx.assets)) }.getOrNull()
}

private fun buildFonts(ctx: Context): List<Pair<String, FontFamily>> {
    val out = mutableListOf<Pair<String, FontFamily>>("Monospace" to FontFamily.Monospace)
    loadAssetFamily(ctx, "JetBrainsMono-Regular.ttf")?.let { out += "JetBrains Mono" to it }
    loadAssetFamily(ctx, "FiraCode-Regular.ttf")?.let { out += "Fira Code" to it }
    return out
}

// ============================================================ utilitários de edição
private fun mapLines(v: TextFieldValue, f: (List<String>) -> List<String>): TextFieldValue {
    val t = v.text; val sel = v.selection
    val s = t.lastIndexOf('\n', sel.min - 1) + 1
    var e = t.indexOf('\n', sel.max).let { if (it < 0) t.length else it }
    if (!sel.collapsed && sel.max > 0 && t[sel.max - 1] == '\n') e = sel.max - 1
    e = maxOf(e, s)
    val block = t.substring(s, e)
    val nb = f(block.split("\n")).joinToString("\n")
    val nt = t.substring(0, s) + nb + t.substring(e)
    val range = if (sel.collapsed) TextRange((sel.min + nb.length - block.length).coerceIn(s, s + nb.length))
                else TextRange(s, s + nb.length)
    return TextFieldValue(nt, range)
}

private fun lineBlock(v: TextFieldValue): Pair<Int, Int> {
    val t = v.text; val sel = v.selection
    val s = t.lastIndexOf('\n', sel.min - 1) + 1
    var e = t.indexOf('\n', sel.max).let { if (it < 0) t.length else it }
    if (!sel.collapsed && sel.max > 0 && t[sel.max - 1] == '\n') e = sel.max - 1
    return s to maxOf(e, s)
}

/** Fecha pares: ( ) [ ] { } " ' — cursor no meio; digitar o fechamento "pula" por cima; Backspace apaga o par. */
private fun autoPair(old: TextFieldValue, nv: TextFieldValue): TextFieldValue {
    if (!old.selection.collapsed || !nv.selection.collapsed) return nv
    val t = nv.text; val o = old.text; val p = nv.selection.start
    if (t.length == o.length + 1 && p > 0 && t.substring(0, p - 1) == o.substring(0, p - 1)) {
        val ch = t[p - 1]; val nextOld = o.getOrNull(p - 1); val prevOld = o.getOrNull(p - 2)
        val atEdge = nextOld == null || nextOld.isWhitespace() || nextOld in ")]};,:"
        when (ch) {
            '(', '[', '{' -> if (atEdge) {
                val close = when (ch) { '(' -> ')'; '[' -> ']'; else -> '}' }
                return TextFieldValue(t.substring(0, p) + close + t.substring(p), TextRange(p))
            }
            ')', ']', '}' -> if (nextOld == ch) return TextFieldValue(o, TextRange(p))
            '"', '\'' -> {
                if (nextOld == ch) return TextFieldValue(o, TextRange(p))
                if (atEdge && (prevOld == null || !(prevOld.isLetterOrDigit() || prevOld == '\\')))
                    return TextFieldValue(t.substring(0, p) + ch + t.substring(p), TextRange(p))
            }
        }
    }
    if (t.length == o.length - 1) {
        val c = old.selection.start
        if (c in 1 until o.length) {
            val a = o[c - 1]; val b = o[c]
            if ((a == '(' && b == ')') || (a == '[' && b == ']') || (a == '{' && b == '}') || (a == b && (a == '"' || a == '\'')))
                return TextFieldValue(o.removeRange(c - 1, c + 1), TextRange(c - 1))
        }
    }
    return nv
}

/** Enter mantém a indentação (+4 após ':' ou abertura de colchete; -4 após return/pass/break/continue/raise). */
private fun autoIndent(old: TextFieldValue, nv: TextFieldValue): TextFieldValue {
    val p = nv.selection.start
    if (!old.selection.collapsed || !nv.selection.collapsed || nv.text.length != old.text.length + 1) return nv
    if (p <= 0 || nv.text[p - 1] != '\n') return nv
    val t = nv.text
    val ls = t.lastIndexOf('\n', p - 2) + 1
    val prev = t.substring(ls, p - 1)
    var ind = prev.takeWhile { it == ' ' || it == '\t' }
    val trimmed = prev.trimEnd()
    val body = trimmed.trimStart()
    val opens = trimmed.isNotEmpty() && (trimmed.last() in "{([:" )
    var extra = if (opens) "    " else ""
    if (!opens && ind.length >= 4 && Regex("^(return|pass|break|continue|raise)\\b").containsMatchIn(body)) ind = ind.dropLast(4)
    if (trimmed.lastOrNull() == '{' && t.getOrNull(p) == '}') {
        val ins = ind + extra + "\n" + ind
        return TextFieldValue(t.substring(0, p) + ins + t.substring(p), TextRange(p + ind.length + extra.length))
    }
    if (ind.isEmpty() && extra.isEmpty()) return nv
    return TextFieldValue(t.substring(0, p) + ind + extra + t.substring(p), TextRange(p + ind.length + extra.length))
}

/** Faixa vermelha na linha do erro + sublinhado ondulado no trecho exato. */
private fun DrawScope.drawDiagnostics(l: TextLayoutResult, text: String, diags: List<Diagnostic>, color: Color) {
    val len = text.length
    if (len == 0) return
    for (d in diags) {
        var s = d.start.coerceIn(0, len); var e = d.end.coerceIn(0, len)
        if (s >= len) s = len - 1
        if (e <= s) e = (s + 1).coerceAtMost(len)
        val ln = l.getLineForOffset(s)
        val lineEnd = text.indexOf('\n', s).let { if (it < 0) len else it }
        val lastLn = l.getLineForOffset(lineEnd.coerceAtMost(len))
        drawRect(color.copy(alpha = 0.12f), Offset(0f, l.getLineTop(ln)), Size(size.width, l.getLineBottom(lastLn) - l.getLineTop(ln)))
        val ce = minOf(e, l.getLineEnd(ln, visibleEnd = true)).coerceAtLeast(s + 1).coerceAtMost(len)
        val b = l.getPathForRange(s, ce).getBounds()
        val left = b.left; val right = maxOf(b.right, b.left + 8.dp.toPx()); val y = b.bottom - 2.dp.toPx()
        val step = 3.dp.toPx(); val amp = 1.6.dp.toPx()
        val path = Path(); var x = left; var up = true
        path.moveTo(x, y)
        while (x < right) { x = minOf(x + step, right); path.lineTo(x, if (up) y - amp else y); up = !up }
        drawPath(path, color, style = Stroke(width = 1.3.dp.toPx()))
    }
}

/** Nível de indentação (em blocos de 4 espaços) de cada linha; linhas em branco herdam o menor vizinho, como no Godot. */
private fun indentLevels(text: String): IntArray {
    val lines = text.split('\n')
    val raw = IntArray(lines.size) { i ->
        val ln = lines[i]
        if (ln.isBlank()) -1 else {
            var n = 0
            for (ch in ln) { if (ch == ' ') n++ else if (ch == '\t') n += 4 else break }
            n
        }
    }
    val next = IntArray(lines.size)
    var nx = 0
    for (i in lines.indices.reversed()) { if (raw[i] >= 0) nx = raw[i]; next[i] = nx }
    val out = IntArray(lines.size)
    var prev = 0
    for (i in lines.indices) {
        if (raw[i] >= 0) { prev = raw[i]; out[i] = raw[i] / 4 } else out[i] = minOf(prev, next[i]) / 4
    }
    return out
}

/** Guias verticais de indentação (uma por bloco de 4 espaços), atrás do texto. */
private fun DrawScope.drawIndentGuides(l: TextLayoutResult, text: String, levels: IntArray, color: Color) {
    if (text.isEmpty()) return
    val ref = text.indexOfFirst { !it.isWhitespace() }
    if (ref < 0) return
    val cw = l.getBoundingBox(ref).width
    if (cw <= 0f) return
    val w = 1.dp.toPx()
    var start = 0
    for (i in levels.indices) {
        val end = text.indexOf('\n', start).let { if (it < 0) text.length else it }
        val lv = levels[i]
        if (lv > 0) {
            val top = l.getLineTop(l.getLineForOffset(start.coerceAtMost(text.length)))
            val bottom = l.getLineBottom(l.getLineForOffset(end.coerceAtMost(text.length)))
            for (k in 0 until lv) {
                val x = k * 4 * cw + w
                drawLine(color, Offset(x, top), Offset(x, bottom), strokeWidth = w)
            }
        }
        start = end + 1
    }
}

private const val SAMPLE = "nome = input(\"Qual é o seu nome? \")\nprint(f\"Olá, {nome}!\")\n"

// ============================================================ tela principal
@Composable
fun CodeEditorScreen() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val session = remember { SessionStore(ctx) }
    val restored = remember { session.load() }
    val tabs = remember {
        mutableStateListOf<EditorTab>().also { it.addAll(restored?.tabs ?: listOf(EditorTab(0, "main.py", null, SAMPLE))) }
    }
    var cur by remember { mutableIntStateOf(restored?.cur ?: 0) }
    var nextId by remember { mutableIntStateOf(restored?.nextId ?: 1) }
    var confirmClose by remember { mutableStateOf<Int?>(null) }

    // ---- preferências do editor
    val prefs = remember { ctx.getSharedPreferences("editor", Context.MODE_PRIVATE) }
    var themeIdx by remember { mutableIntStateOf(prefs.getInt("theme", 0).coerceIn(0, CodeThemes.all.lastIndex)) }
    val theme = CodeThemes.all[themeIdx]
    val fonts = remember { buildFonts(ctx) }
    var fontIdx by remember { mutableIntStateOf(prefs.getInt("font", 1).coerceIn(0, fonts.lastIndex)) }
    val family = fonts[fontIdx].second
    var fontSize by remember { mutableFloatStateOf(prefs.getFloat("size", 14f).coerceIn(8f, 40f)) }
    var autoSave by remember { mutableStateOf(prefs.getBoolean("autosave", true)) }
    var floatRun by remember { mutableStateOf(prefs.getBoolean("floatRun", false)) }
    var guides by remember { mutableStateOf(prefs.getBoolean("guides", true)) }
    var lastRunId by remember { mutableIntStateOf(-1) }
    LaunchedEffect(fontSize) { delay(400); prefs.edit().putFloat("size", fontSize).apply() }

    val explorer = remember { ProjectExplorerState(ctx) }
    var showSidebar by remember { mutableStateOf(false) }

    var showFind by remember { mutableStateOf(false) }
    var showReplace by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var useRegex by remember { mutableStateOf(false) }
    var showSnippets by remember { mutableStateOf(false) }
    var showGoto by remember { mutableStateOf(false) }
    var gotoText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var showConsole by remember { mutableStateOf(false) }
    var consoleBig by remember { mutableStateOf(false) }
    var editorFocused by remember { mutableStateOf(false) }
    var showAllDiags by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val snippets = remember { mutableStateListOf<Pair<String, String>>().also { it.addAll(SnippetStore(ctx).load()) } }
    fun persistSnippets() = SnippetStore(ctx).save(snippets.toList())
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    fun current() = tabs[cur.coerceIn(0, tabs.lastIndex)]
    val tab = current()
    val text = tab.value.text

    val runState by PyRunner.state.collectAsState()
    val running = runState != RunState.IDLE

    // ---------- Fechar abas
    fun removeTab(i: Int) {
        if (tabs.size <= 1 || i !in tabs.indices) return
        val active = cur.coerceIn(0, tabs.lastIndex)
        tabs.removeAt(i)
        cur = when { i < active -> active - 1; i == active -> minOf(active, tabs.lastIndex); else -> active }
    }
    fun requestClose(i: Int) {
        val t = tabs.getOrNull(i) ?: return
        if (t.dirty) confirmClose = t.id else removeTab(i)
    }
    fun addNewTab() { tabs.add(EditorTab(nextId, "novo$nextId.py")); nextId++; cur = tabs.lastIndex }

    // ---------- Arquivos (SAF)
    fun writeTo(t: EditorTab, uri: Uri, quiet: Boolean = false): Boolean =
        if (ProjectFs.writeText(ctx, uri, t.value.text)) { t.dirty = false; if (!quiet) toast("Salvo: ${t.name}"); true }
        else { toast("Erro ao salvar ${t.name}"); false }

    fun saveAll() {
        val dirty = tabs.filter { it.dirty }
        val withUri = dirty.filter { it.uri != null }
        val ok = withUri.count { writeTo(it, it.uri!!, true) }
        val skipped = dirty.size - withUri.size
        toast(if (dirty.isEmpty()) "Nada para salvar" else "Salvos: $ok" + if (skipped > 0) " · $skipped sem arquivo (use Salvar como)" else "")
    }

    fun openProjectFile(e: DocEntry) {
        val t = explorer.treeUri ?: return
        val uri = ProjectFs.docUri(t, e.id)
        val existing = tabs.indexOfFirst { it.uri == uri }
        if (existing >= 0) { cur = existing; if (!wide) showSidebar = false; return }
        scope.launch {
            val txt = withContext(Dispatchers.IO) { ProjectFs.readText(ctx, uri) }
            if (txt == null) toast("Não abri (binário ou maior que 2 MB): ${e.name}")
            else { tabs.add(EditorTab(nextId++, e.name, uri, txt)); cur = tabs.lastIndex; if (!wide) showSidebar = false }
        }
    }

    fun onDocChanged(oldId: String, newId: String?) {
        val t = explorer.treeUri ?: return
        tabs.forEach { tb ->
            val u = tb.uri ?: return@forEach
            val nu = ProjectFs.remap(u, t, oldId, newId)
            if (nu == null) { tb.uri = null; tb.dirty = true }
            else if (nu != u) { tb.uri = nu; tb.name = displayName(ctx, nu) }
        }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            val txt = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            tabs.add(EditorTab(nextId++, displayName(ctx, uri), uri, txt)); cur = tabs.lastIndex
        }.onFailure { toast("Erro ao abrir: ${it.message}") }
    }
    val saveAsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-python")) { uri ->
        if (uri != null) { val t = current(); t.uri = uri; t.name = displayName(ctx, uri); writeTo(t, uri) }
    }
    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            val rootId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull()
            if (rootId == null) toast("Pasta inválida")
            else {
                val nm = displayNameOrNull(ctx, DocumentsContract.buildDocumentUriUsingTree(uri, rootId)) ?: rootId.substringAfterLast('/').ifEmpty { "Projeto" }
                explorer.setRoot(uri, nm); showSidebar = true
            }
        }
    }

    // ---------- Edição
    fun edit(f: (TextFieldValue) -> TextFieldValue) { val t = current(); t.change(f(t.value)) }
    fun insert(s: String) = edit { v ->
        TextFieldValue(v.text.substring(0, v.selection.min) + s + v.text.substring(v.selection.max), TextRange(v.selection.min + s.length))
    }
    fun insertWithBack(s: String, back: Int) = edit { v ->
        val a = v.selection.min; val b = v.selection.max
        if (s.length == 2 && back == 1 && a != b) {
            val sel = v.text.substring(a, b)
            TextFieldValue(v.text.substring(0, a) + s[0] + sel + s[1] + v.text.substring(b), TextRange(a + sel.length + 2))
        } else TextFieldValue(v.text.substring(0, a) + s + v.text.substring(b), TextRange(a + s.length - back))
    }
    fun applySuggestion(prefixLen: Int, ins: String, back: Int) = edit { v ->
        val c = v.selection.start; val st = (c - prefixLen).coerceAtLeast(0)
        var s = ins; var bk = back
        if (s.endsWith("()") && v.text.getOrNull(c) == '(') { s = s.dropLast(2); bk = 0 }
        TextFieldValue(v.text.substring(0, st) + s + v.text.substring(c), TextRange(st + s.length - bk))
    }
    fun selectedOrAll(): String { val v = current().value; return if (v.selection.collapsed) v.text else v.text.substring(v.selection.min, v.selection.max) }

    fun doToggleComment() = edit { v -> mapLines(v) { ls ->
        val nonBlank = ls.filter { it.isNotBlank() }
        val all = nonBlank.isNotEmpty() && nonBlank.all { it.trimStart().startsWith("#") }
        ls.map { l ->
            val ind = l.takeWhile { it == ' ' || it == '\t' }; val body = l.trimStart()
            when { l.isBlank() -> l; all -> ind + body.removePrefix("#").removePrefix(" "); else -> "$ind# $body" }
        }
    } }

    fun runTab(t: EditorTab) {
        if (PyRunner.state.value != RunState.IDLE) { toast("Já existe um script em execução"); return }
        showConsole = true
        lastRunId = t.id
        val siblings = tabs.filter { it !== t && it.name.endsWith(".py") }.associate { it.name to it.value.text }
        PyRunner.run(ctx, t.value.text, t.name, siblings)
    }
    fun doRun() = runTab(current())
    /** Roda de novo o último arquivo executado (com o texto atual dele). */
    fun doRerun() = runTab(tabs.firstOrNull { it.id == lastRunId } ?: current())
    fun doStop() = PyRunner.stop()

    fun doDuplicate() {
        val t = current(); val v = t.value; val txt = v.text
        if (!v.selection.collapsed) {
            val sel = txt.substring(v.selection.min, v.selection.max)
            t.change(TextFieldValue(txt.substring(0, v.selection.max) + sel + txt.substring(v.selection.max), TextRange(v.selection.max, v.selection.max + sel.length)))
            return
        }
        val (s, e) = lineBlock(v); val line = txt.substring(s, e)
        t.change(TextFieldValue(txt.substring(0, e) + "\n" + line + txt.substring(e), TextRange(v.selection.min + line.length + 1)))
    }

    fun doMoveLine(up: Boolean) {
        val t = current(); val v = t.value; val txt = v.text
        val (s, e) = lineBlock(v); val block = txt.substring(s, e)
        if (up) {
            if (s == 0) return
            val ps = txt.lastIndexOf('\n', s - 2) + 1; val prev = txt.substring(ps, s - 1); val d = prev.length + 1
            t.change(TextFieldValue(txt.substring(0, ps) + block + "\n" + prev + txt.substring(e), TextRange(v.selection.start - d, v.selection.end - d)))
        } else {
            if (e >= txt.length) return
            val ne = txt.indexOf('\n', e + 1).let { if (it < 0) txt.length else it }
            val next = txt.substring(e + 1, ne); val d = next.length + 1
            t.change(TextFieldValue(txt.substring(0, s) + next + "\n" + block + txt.substring(ne), TextRange(v.selection.start + d, v.selection.end + d)))
        }
    }

    fun doDeleteLine() {
        val t = current(); val v = t.value; val txt = v.text
        val (s, e) = lineBlock(v)
        val (a, b) = when { e < txt.length -> s to e + 1; s > 0 -> (s - 1) to e; else -> s to e }
        t.change(TextFieldValue(txt.removeRange(a, b), TextRange(a)))
    }

    fun doSelectLine() {
        val t = current(); val v = t.value; val (s, e) = lineBlock(v)
        t.value = v.copy(selection = TextRange(s, minOf(e + 1, v.text.length)))
    }

    fun gotoOffset(off: Int) { val t = current(); t.value = t.value.copy(selection = TextRange(off.coerceIn(0, t.value.text.length))); runCatching { focus.requestFocus() } }

    fun gotoLine(n: Int) {
        val txt = current().value.text
        var off = 0; var line = 1
        while (line < n) { val i = txt.indexOf('\n', off); if (i < 0) break; off = i + 1; line++ }
        gotoOffset(off)
    }

    fun regexOf() = if (useRegex) Regex(query) else Regex(Regex.escape(query))
    fun doFindNext() {
        if (query.isEmpty()) return
        val t = current(); val txt = t.value.text
        runCatching {
            val p = regexOf()
            val m = p.find(txt, t.value.selection.max.coerceAtMost(txt.length)) ?: p.find(txt, 0)
            if (m != null) { t.value = t.value.copy(selection = TextRange(m.range.first, m.range.last + 1)); runCatching { focus.requestFocus() } }
            else toast("Não encontrado")
        }.onFailure { toast("Regex inválida") }
    }
    fun replaceOne() {
        val v = current().value
        if (v.selection.collapsed) { doFindNext(); return }
        runCatching {
            val p = regexOf()
            val sel = v.text.substring(v.selection.min, v.selection.max)
            if (p.matches(sel)) insert(p.replaceFirst(sel, if (useRegex) repl else Regex.escapeReplacement(repl)))
            doFindNext()
        }.onFailure { toast("Regex inválida") }
    }
    fun replaceAll() {
        if (query.isEmpty()) return
        runCatching {
            val p = regexOf()
            edit { v -> TextFieldValue(p.replace(v.text, if (useRegex) repl else Regex.escapeReplacement(repl)), TextRange(0)) }
        }.onFailure { toast("Regex inválida") }
    }

    fun formatCode() {
        val t = current()
        val o = t.value.text.lines().joinToString("\n") { it.trimEnd() }.let { if (it.endsWith("\n")) it else it + "\n" }
        t.change(TextFieldValue(o, TextRange(minOf(t.value.selection.start, o.length))))
    }

    fun applyFix(f: QuickFix) {
        val t = current(); val s = t.value.text
        val a = f.start.coerceIn(0, s.length); val b = f.end.coerceIn(a, s.length)
        t.change(TextFieldValue(s.replaceRange(a, b, f.replacement), TextRange(a + f.replacement.length)))
        runCatching { focus.requestFocus() }
    }

    val actions = remember {
        object : EditorActions {
            override fun save() { val t = current(); val u = t.uri; if (u != null) writeTo(t, u) else saveAsLauncher.launch(t.name) }
            override fun saveAs() { saveAsLauncher.launch(current().name) }
            override fun openFile() { openLauncher.launch(arrayOf("*/*")) }
            override fun newTab() = addNewTab()
            override fun closeTab() = requestClose(cur.coerceIn(0, tabs.lastIndex))
            override fun switchTab(delta: Int) { cur = (cur.coerceIn(0, tabs.lastIndex) + delta + tabs.size) % tabs.size }
            override fun runCode() = doRun()
            override fun stopCode() = doStop()
            override fun undo() = current().undo()
            override fun redo() = current().redo()
            override fun copy() {
                val v = current().value
                if (v.selection.collapsed) {
                    val s = v.text.lastIndexOf('\n', v.selection.min - 1) + 1
                    val e = v.text.indexOf('\n', v.selection.min).let { if (it < 0) v.text.length else it }
                    clipboard.setText(AnnotatedString(v.text.substring(s, e)))
                } else clipboard.setText(AnnotatedString(selectedOrAll()))
            }
            override fun paste() { clipboard.getText()?.text?.let { insert(it) } }
            override fun cut() { if (!current().value.selection.collapsed) { clipboard.setText(AnnotatedString(selectedOrAll())); insert("") } }
            override fun find() { showFind = true; showReplace = false }
            override fun replace() { showFind = true; showReplace = true }
            override fun findNext() = doFindNext()
            override fun toggleComment() = doToggleComment()
            override fun indent() { if (current().value.selection.collapsed) insert("    ") else edit { v -> mapLines(v) { l -> l.map { "    $it" } } } }
            override fun outdent() = edit { v -> mapLines(v) { l -> l.map { it.replaceFirst(Regex("^( {1,4}|\t)"), "") } } }
            override fun duplicateLine() = doDuplicate()
            override fun moveLine(up: Boolean) = doMoveLine(up)
            override fun deleteLine() = doDeleteLine()
            override fun selectLine() = doSelectLine()
            override fun goToLine() { showGoto = true }
            override fun format() = formatCode()
            override fun toggleSidebar() { showSidebar = !showSidebar }
            override fun escape(): Boolean = when {
                showFind -> { showFind = false; true }
                showSidebar -> { showSidebar = false; true }
                showConsole && PyRunner.state.value == RunState.IDLE -> { showConsole = false; true }
                else -> false
            }
        }
    }
    val keys = remember { KeyBindingHandler(actions) }

    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    fun moveCursor(dx: Int, dy: Int) {
        val t = current(); val v = t.value; val pos = v.selection.max
        val l = layout
        val np = if (dy == 0) (pos + dx).coerceIn(0, v.text.length) else l?.let {
            val ln = (it.getLineForOffset(pos) + dy).coerceIn(0, it.lineCount - 1)
            it.getOffsetForPosition(Offset(it.getHorizontalPosition(pos, true), (it.getLineTop(ln) + it.getLineBottom(ln)) / 2))
        } ?: pos
        t.value = v.copy(selection = TextRange(np))
    }

    // ---------- Diagnósticos (scanner rápido -> CPython real) + erro de execução
    var staticDiags by remember(tab.id) { mutableStateOf<List<Diagnostic>>(emptyList()) }
    LaunchedEffect(tab.id, text) {
        staticDiags = withContext(Dispatchers.Default) { SyntaxAnalyzer.analyzeFast(text) }
        delay(350)
        staticDiags = withContext(Dispatchers.Default) { SyntaxAnalyzer.analyze(text, tab.name) }
    }
    val rtErr by PyRunner.error.collectAsState()
    val rtDiag = remember(rtErr, text, tab.name) {
        rtErr?.takeIf { it.fileName == tab.name && it.sourceHash == text.hashCode() }?.let { SyntaxAnalyzer.fromRuntime(it, text) }
    }
    val diags = remember(staticDiags, rtDiag) { (staticDiags + listOfNotNull(rtDiag)).distinctBy { it.line to it.message } }
    val cursorLine = text.take(tab.value.selection.min.coerceIn(0, text.length)).count { it == '\n' } + 1
    val activeDiag = diags.firstOrNull { it.line == cursorLine } ?: diags.firstOrNull()

    LaunchedEffect(tab.id) { runCatching { focus.requestFocus() } }
    LaunchedEffect(tab.id, text, autoSave) {
        val u = tab.uri
        if (autoSave && u != null && tab.dirty) { delay(400); if (tab.dirty) writeTo(tab, u, true) }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { Triple(tabs.map { it.toSession() }, cur, nextId) }.collectLatest { (list, c, n) ->
            delay(500)
            withContext(Dispatchers.IO) { session.save(list, c, n) }
        }
    }

    // ============================================================ UI
    Box(
        Modifier.fillMaxSize().background(theme.bg).pointerInput(Unit) {
            // arrastar a partir da borda esquerda abre o gerenciador de arquivos
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                if (down.position.x <= 48.dp.toPx()) {
                    var dx = 0f
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val ch = ev.changes.firstOrNull() ?: break
                        if (!ch.pressed) break
                        dx += ch.positionChange().x
                        if (dx > 56.dp.toPx()) { showSidebar = true; ch.consume(); break }
                    }
                }
            }
        }
    ) {
        Row(Modifier.fillMaxSize()) {
            if (showSidebar && wide) FileExplorerSidebar(
                explorer, theme, tab.uri, { treeLauncher.launch(null) }, ::openProjectFile, ::onDocChanged, { showSidebar = false },
                Modifier.width(280.dp).fillMaxHeight()
            )
            Column(Modifier.weight(1f).fillMaxHeight()) {
                // ---- abas
                Row(Modifier.fillMaxWidth().background(theme.bar).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    tabs.forEachIndexed { i, t ->
                        Row(
                            Modifier.background(if (i == cur) theme.bg else theme.bar).clickable { cur = i }.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text((if (t.dirty) "● " else "") + t.name, fontSize = 13.sp, color = theme.text)
                            if (tabs.size > 1) Text("  ✕", fontSize = 13.sp, color = theme.gutterText, modifier = Modifier.clickable { requestClose(i) })
                        }
                    }
                    Btn("＋", theme) { addNewTab() }
                }
                // ---- barra de ferramentas
                Row(Modifier.fillMaxWidth().background(theme.bar).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    Btn("☰", theme) { showSidebar = !showSidebar }
                    if (running) Btn("■ Parar", theme, theme.error) { doStop() } else Btn("▶ Executar", theme, theme.function) { doRun() }
                    Btn("Salvar", theme) { actions.save() }
                    Btn("Buscar", theme) { actions.find() }
                    Btn("Console", theme) { showConsole = !showConsole }
                    Btn("A−", theme) { fontSize = (fontSize - 1f).coerceAtLeast(8f) }
                    Btn("A+", theme) { fontSize = (fontSize + 1f).coerceAtMost(40f) }
                    Box {
                        Btn("⋮", theme) { showMenu = true }
                        DropdownMenu(showMenu, { showMenu = false }) {
                            @Composable
                            fun item(label: String, run: () -> Unit) = DropdownMenuItem(text = { Text(label) }, onClick = { showMenu = false; run() })
                            item("Abrir arquivo…") { actions.openFile() }
                            item("Salvar como…") { actions.saveAs() }
                            item("Salvar tudo") { saveAll() }
                            item("Ir para linha…") { showGoto = true }
                            item("Substituir…") { actions.replace() }
                            item("Formatar (espaços finais)") { formatCode() }
                            item("Indentar") { actions.indent() }
                            item("Desindentar") { actions.outdent() }
                            item("Snippets…") { showSnippets = true }
                            item("Tema: ${theme.name}") { themeIdx = (themeIdx + 1) % CodeThemes.all.size; prefs.edit().putInt("theme", themeIdx).apply() }
                            item("Fonte: ${fonts[fontIdx].first}") { fontIdx = (fontIdx + 1) % fonts.size; prefs.edit().putInt("font", fontIdx).apply() }
                            item(if (autoSave) "Auto-save: ON" else "Auto-save: OFF") { autoSave = !autoSave; prefs.edit().putBoolean("autosave", autoSave).apply() }
                            item(if (guides) "Guias de indentação: ON" else "Guias de indentação: OFF") { guides = !guides; prefs.edit().putBoolean("guides", guides).apply() }
                            item(if (floatRun) "Botão executar flutuante: ON" else "Botão executar flutuante: OFF") { floatRun = !floatRun; prefs.edit().putBoolean("floatRun", floatRun).apply() }
                        }
                    }
                }
                // ---- busca / substituição
                if (showFind) Column(Modifier.fillMaxWidth().background(theme.bar).padding(horizontal = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, label = { Text("Buscar") })
                        Checkbox(useRegex, { useRegex = it }); Text("Regex", fontSize = 12.sp, color = theme.text)
                        Btn("Próx.", theme) { doFindNext() }
                        Btn("✕", theme) { showFind = false }
                    }
                    if (showReplace) Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(repl, { repl = it }, Modifier.weight(1f), singleLine = true, label = { Text("Substituir por") })
                        Btn("Substituir", theme) { replaceOne() }
                        Btn("Todos", theme) { replaceAll() }
                    }
                }
                // ---- editor
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val minH = maxHeight
                    val density = LocalDensity.current
                    val viewportPx = with(density) { minH.roundToPx() }
                    key(tab.id) {
                        val scroll = rememberScrollState()
                        val lineH = fontSize * 1.45f
                        val textStyle = TextStyle(fontFamily = family, fontSize = fontSize.sp, lineHeight = lineH.sp, color = theme.text)
                        val measurer = rememberTextMeasurer()
                        // mantém o cursor visível
                        LaunchedEffect(tab.value.selection, layout) {
                            val l = layout ?: return@LaunchedEffect
                            val c = l.getCursorRect(tab.value.selection.end.coerceIn(0, text.length))
                            val pad = with(density) { 8.dp.roundToPx() }
                            val top = c.top.toInt() + pad; val bottom = c.bottom.toInt() + pad
                            if (top < scroll.value) scroll.scrollTo((top - 8).coerceAtLeast(0))
                            else if (bottom > scroll.value + viewportPx) scroll.scrollTo(bottom - viewportPx + 8)
                        }
                        Box(
                            Modifier.fillMaxSize().pointerInput(Unit) {
                                // pinch-to-zoom: só consome com 2+ dedos (1 dedo continua rolando/selecionando)
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    do {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        if (ev.changes.size >= 2 && ev.changes.all { it.pressed }) {
                                            val z = ev.calculateZoom()
                                            if (z != 1f) { fontSize = (fontSize * z).coerceIn(8f, 40f); ev.changes.forEach { it.consume() } }
                                        }
                                    } while (ev.changes.any { it.pressed })
                                }
                            }
                        ) {
                            Box(Modifier.fillMaxSize().verticalScroll(scroll).padding(8.dp)) {
                                Row(Modifier.fillMaxWidth()) {
                                    val digits = (text.count { it == '\n' } + 1).toString().length.coerceAtLeast(2)
                                    val gutterW = (digits * fontSize * 0.62f + 30f).dp
                                    val curLine0 = cursorLine - 1
                                    val gh = with(density) { (layout?.size?.height ?: 0).toDp() }
                                    Canvas(Modifier.width(gutterW).height(maxOf(gh, minH)).background(theme.gutterBg)) {
                                        val l = layout ?: return@Canvas
                                        val errLines = diags.map { it.line }.toSet()
                                        var logical = -1
                                        for (i in 0 until l.lineCount) {
                                            val st = l.getLineStart(i)
                                            if (i == 0 || text.getOrNull(st - 1) == '\n') {
                                                logical++
                                                val isErr = (logical + 1) in errLines
                                                val r = measurer.measure(
                                                    (logical + 1).toString(),
                                                    TextStyle(fontFamily = family, fontSize = (fontSize * 0.9f).sp, lineHeight = lineH.sp,
                                                        color = if (isErr) theme.error else if (logical == curLine0) theme.gutterActive else theme.gutterText)
                                                )
                                                drawText(r, topLeft = Offset(size.width - r.size.width - 10.dp.toPx(), l.getLineTop(i)))
                                                if (isErr) drawCircle(theme.error, 3.5.dp.toPx(), Offset(8.dp.toPx(), (l.getLineTop(i) + l.getLineBottom(i)) / 2))
                                            }
                                        }
                                    }
                                    Box(Modifier.weight(1f).padding(start = 6.dp)) {
                                        val indentLv = remember(text) { indentLevels(text) }
                                        val vt = remember(theme) {
                                            VisualTransformation { t -> TransformedText(SyntaxAnalyzer.highlight(t.text, theme), OffsetMapping.Identity) }
                                        }
                                        BasicTextField(
                                            value = tab.value,
                                            onValueChange = { tab.change(autoIndent(tab.value, autoPair(tab.value, it))) },
                                            textStyle = textStyle,
                                            cursorBrush = SolidColor(theme.cursor),
                                            visualTransformation = vt,
                                            onTextLayout = { layout = it },
                                            keyboardOptions = KeyboardOptions(autoCorrectEnabled = false),
                                            modifier = Modifier.fillMaxWidth().heightIn(min = minH)
                                                .drawBehind {
                                                    layout?.let {
                                                        if (guides) drawIndentGuides(it, text, indentLv, theme.gutterText.copy(alpha = 0.35f))
                                                        drawDiagnostics(it, text, diags, theme.error)
                                                    }
                                                }
                                                .focusRequester(focus)
                                                .onFocusChanged { editorFocused = it.isFocused }
                                                .onPreviewKeyEvent { keys.handle(it) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                // ---- console interativo
                if (showConsole) ConsolePanel(
                    theme, family, fontSize, consoleBig, { consoleBig = !consoleBig }, { showConsole = false }, { doRerun() },
                    Modifier.fillMaxWidth().weight(if (consoleBig) 2f else 1f)
                )
                // ---- diagnósticos
                DiagnosticsBanner(
                    diags, activeDiag, theme, showAllDiags, { showAllDiags = !showAllDiags },
                    onJump = { d -> gotoOffset(d.start) }, onFix = { applyFix(it) }
                )
                // ---- sugestões + atalhos (acima do teclado)
                if (editorFocused) KeyboardSuggestionBar(
                    text = text, cursor = tab.value.selection.start, theme = theme,
                    canUndo = tab.undoCount > 0, canRedo = tab.redoCount > 0,
                    onSuggestion = ::applySuggestion,
                    onUndo = { actions.undo() }, onRedo = { actions.redo() },
                    onMove = { dx, dy -> moveCursor(dx, dy) }, onTab = { actions.indent() },
                    onCopy = { actions.copy() }, onPaste = { actions.paste() }
                )
            }
        }
        // botão executar flutuante (opção do menu ⋮), arrastável
        if (floatRun) {
            var fab by remember { mutableStateOf(Offset.Zero) }
            Box(
                Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 130.dp)
                    .offset { IntOffset(fab.x.roundToInt(), fab.y.roundToInt()) }
                    .size(54.dp).clip(CircleShape)
                    .background(if (running) theme.error else theme.function)
                    .pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); fab += drag } }
                    .clickable { if (running) doStop() else doRun() },
                contentAlignment = Alignment.Center
            ) { Text(if (running) "■" else "▶", color = theme.bg, fontSize = 22.sp) }
        }
        // gerenciador de arquivos sobreposto em telas estreitas (arraste para a esquerda ou toque fora para fechar)
        if (!wide) {
            AnimatedVisibility(showSidebar, enter = slideInHorizontally { -it }, exit = slideOutHorizontally { -it }) {
                Row(Modifier.fillMaxSize()) {
                    FileExplorerSidebar(
                        explorer, theme, tab.uri, { treeLauncher.launch(null) }, ::openProjectFile, ::onDocChanged, { showSidebar = false },
                        Modifier.width(310.dp).fillMaxHeight().pointerInput(Unit) {
                            var total = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { total = 0f },
                                onDragEnd = { if (total < -60f) showSidebar = false },
                                onHorizontalDrag = { _, d -> total += d }
                            )
                        }
                    )
                    Box(Modifier.weight(1f).fillMaxHeight().background(Color(0x66000000)).clickable { showSidebar = false })
                }
            }
        }
    }

    // ============================================================ diálogos
    val closing = confirmClose?.let { id -> tabs.firstOrNull { it.id == id } }
    if (closing != null) AlertDialog(
        onDismissRequest = { confirmClose = null },
        title = { Text("Fechar \"${closing.name}\"?") },
        text = { Text("Há alterações não salvas nesta aba.") },
        confirmButton = {
            Row {
                val u = closing.uri
                if (u != null) TextButton({ writeTo(closing, u); confirmClose = null; removeTab(tabs.indexOfFirst { it.id == closing.id }) }) { Text("Salvar e fechar") }
                TextButton({ confirmClose = null; removeTab(tabs.indexOfFirst { it.id == closing.id }) }) { Text("Fechar sem salvar") }
            }
        },
        dismissButton = { TextButton({ confirmClose = null }) { Text("Cancelar") } }
    )

    if (showGoto) AlertDialog(
        onDismissRequest = { showGoto = false },
        confirmButton = { TextButton({ gotoLine(gotoText.toIntOrNull() ?: 1); showGoto = false }) { Text("Ir") } },
        title = { Text("Ir para a linha") },
        text = { OutlinedTextField(gotoText, { gotoText = it.filter(Char::isDigit) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
    )

    if (showSnippets) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSnippets = false },
            confirmButton = { TextButton({ showSnippets = false }) { Text("Fechar") } },
            title = { Text("Snippets") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    snippets.forEachIndexed { i, (n, b) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(n, Modifier.weight(1f).clickable { insert(b); showSnippets = false }.padding(8.dp))
                            Text("🗑", Modifier.clickable { snippets.removeAt(i); persistSnippets() }.padding(8.dp))
                        }
                    }
                    OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Nome do novo snippet") })
                    TextButton({ if (name.isNotBlank()) { snippets.add(name.trim() to selectedOrAll()); persistSnippets(); name = "" } }) {
                        Text("Salvar seleção (ou arquivo) como snippet")
                    }
                }
            }
        )
    }
}

// ============================================================ painel de diagnósticos
@Composable
private fun DiagnosticsBanner(
    diags: List<Diagnostic>, active: Diagnostic?, theme: CodeTheme,
    expanded: Boolean, onToggle: () -> Unit,
    onJump: (Diagnostic) -> Unit, onFix: (QuickFix) -> Unit
) {
    if (active == null) {
        Text("✓ Sem erros de sintaxe", Modifier.fillMaxWidth().background(theme.bar).padding(horizontal = 10.dp, vertical = 4.dp),
            color = theme.function, fontSize = 12.sp)
        return
    }
    Column(Modifier.fillMaxWidth().background(theme.bar)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable { onJump(active) }) {
                Text("${active.kind} · linha ${active.line}, coluna ${active.column}", color = theme.error, fontSize = 11.sp)
                Text(active.message, color = theme.text, fontSize = 13.sp)
                active.suggestion?.let { Text("💡 $it", color = theme.string, fontSize = 12.sp) }
            }
            active.fix?.let { f -> Btn("Aplicar", theme, theme.function) { onFix(f) } }
            if (diags.size > 1) Btn("${diags.size}", theme, theme.error) { onToggle() }
        }
        if (expanded && diags.size > 1) Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
            diags.forEach { d ->
                Text("L${d.line}:${d.column}  ${d.message}", Modifier.fillMaxWidth().clickable { onJump(d) }.padding(horizontal = 12.dp, vertical = 5.dp),
                    color = theme.text, fontSize = 12.sp)
            }
        }
    }
}

// ============================================================ console de terminal
@Composable
private fun ConsolePanel(
    theme: CodeTheme, family: FontFamily, fontSize: Float,
    big: Boolean, onToggleBig: () -> Unit, onClose: () -> Unit, onRerun: () -> Unit, modifier: Modifier
) {
    val chunks by PyRunner.chunks.collectAsState()
    val state by PyRunner.state.collectAsState()
    val prompt by PyRunner.prompt.collectAsState()
    val stuck by PyRunner.stuck.collectAsState()
    val running = state != RunState.IDLE
    var input by remember { mutableStateOf("") }
    val inputFocus = remember { FocusRequester() }
    var confirmKill by remember { mutableStateOf(false) }

    val annotated = remember(chunks, theme) {
        var budget = 20_000
        val parts = ArrayList<ConsoleChunk>()
        for (c in chunks.asReversed()) {
            if (budget <= 0) break
            if (c.text.length <= budget) { parts += c; budget -= c.text.length } else { parts += c.copy(text = c.text.takeLast(budget)); budget = 0 }
        }
        parts.reverse()
        buildAnnotatedString {
            if (chunks.sumOf { it.text.length } > 20_000) append("…\n")
            parts.forEach {
                val col = when (it.kind) {
                    StreamKind.OUT -> theme.text; StreamKind.ERR -> theme.error; StreamKind.IN -> theme.string; StreamKind.SYS -> theme.comment
                }
                withStyle(SpanStyle(color = col)) { append(it.text) }
            }
        }
    }
    LaunchedEffect(prompt != null) { if (prompt != null) runCatching { inputFocus.requestFocus() } }

    fun send() { if (prompt != null) { PyRunner.sendInput(input); input = "" } }

    Column(modifier.background(Color(0xFF111111))) {
        Row(Modifier.fillMaxWidth().background(theme.bar), verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (state) {
                    RunState.IDLE -> "Console"; RunState.STARTING -> "Console · iniciando Python…"
                    RunState.RUNNING -> "Console · executando"; RunState.WAITING_INPUT -> "Console · aguardando input()"
                    RunState.STOPPING -> "Console · parando…"
                },
                Modifier.weight(1f).padding(start = 10.dp), color = theme.text, fontSize = 12.sp
            )
            if (running) Btn("■ Parar", theme, theme.error) { PyRunner.stop() } else Btn("↻ Repetir", theme, theme.function) { onRerun() }
            if (stuck) Btn("Forçar encerramento", theme, theme.error) { confirmKill = true }
            Btn("Limpar", theme) { PyRunner.clearConsole() }
            Btn(if (big) "⤡" else "⤢", theme) { onToggleBig() }
            Btn("✕", theme) { onClose() }
        }
        val sc = rememberScrollState()
        LaunchedEffect(annotated, sc.maxValue) { sc.scrollTo(sc.maxValue) }
        Text(
            annotated,
            Modifier.weight(1f).fillMaxWidth().verticalScroll(sc).padding(8.dp),
            fontFamily = family, fontSize = (fontSize - 1f).coerceAtLeast(9f).sp, lineHeight = ((fontSize - 1f) * 1.35f).sp
        )
        if (running) Row(Modifier.fillMaxWidth().background(theme.bar).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (prompt != null) "▸" else "…", color = theme.string, fontFamily = family, modifier = Modifier.padding(horizontal = 6.dp))
            BasicTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f).padding(vertical = 8.dp).focusRequester(inputFocus),
                singleLine = true,
                textStyle = TextStyle(color = theme.text, fontFamily = family, fontSize = fontSize.sp),
                cursorBrush = SolidColor(theme.cursor),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send, autoCorrectEnabled = false),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Btn("Enviar", theme, theme.function) { send() }
            Btn("EOF", theme) { PyRunner.sendEof() }
        }
    }
    if (confirmKill) AlertDialog(
        onDismissRequest = { confirmKill = false },
        title = { Text("Forçar encerramento?") },
        text = { Text("O Python roda dentro do app, então isso fecha o app inteiro. Arquivos com auto-save já estão gravados; reabra o app depois.") },
        confirmButton = { TextButton({ PyRunner.forceKill() }) { Text("Encerrar") } },
        dismissButton = { TextButton({ confirmKill = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun Btn(label: String, theme: CodeTheme, color: Color = theme.text, onClick: () -> Unit) =
    TextButton(onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text(label, fontSize = 12.sp, color = color) }
