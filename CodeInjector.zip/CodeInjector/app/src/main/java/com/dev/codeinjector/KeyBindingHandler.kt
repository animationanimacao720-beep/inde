package com.dev.codeinjector

import androidx.compose.ui.input.key.*

interface EditorActions {
    fun save(); fun saveAs(); fun openFile(); fun newTab(); fun closeTab(); fun switchTab(delta: Int)
    fun inject(); fun runCode(); fun stopCode(); fun undo(); fun redo()
    fun copy(); fun paste(); fun cut()
    fun find(); fun replace(); fun findNext(); fun toggleComment()
    fun indent(); fun outdent()
    fun duplicateLine(); fun moveLine(up: Boolean); fun deleteLine(); fun selectLine()
    fun goToLine(); fun format(); fun toggleSidebar()
    /** Retorna true se fechou algo (busca, console...). */
    fun escape(): Boolean
}

/**
 * Atalhos do teclado físico. Ctrl+R = rodar, Ctrl+S = salvar, Ctrl+F = buscar.
 * Setas, Shift+setas, Home/End, Ctrl+A, Delete etc. já são tratados pelo BasicTextField.
 */
class KeyBindingHandler(private val a: EditorActions) {
    fun handle(e: KeyEvent): Boolean {
        if (e.type != KeyEventType.KeyDown) return false
        val ctrl = e.isCtrlPressed; val shift = e.isShiftPressed; val alt = e.isAltPressed
        val k = e.key
        return when {
            alt && k == Key.Enter -> { a.inject(); true }
            alt && k == Key.DirectionUp -> { a.moveLine(true); true }
            alt && k == Key.DirectionDown -> { a.moveLine(false); true }
            shift && k == Key.F5 -> { a.stopCode(); true }
            ctrl && k == Key.Period -> { a.stopCode(); true }
            (ctrl && k == Key.R) || (ctrl && k == Key.Enter) || k == Key.F5 -> { a.runCode(); true }
            ctrl && shift && k == Key.Z -> { a.redo(); true }
            ctrl && shift && k == Key.S -> { a.saveAs(); true }
            ctrl && shift && k == Key.K -> { a.deleteLine(); true }
            ctrl && shift && k == Key.F -> { a.format(); true }
            ctrl && k == Key.Tab -> { a.switchTab(if (shift) -1 else 1); true }
            ctrl && k == Key.Z -> { a.undo(); true }
            ctrl && k == Key.Y -> { a.redo(); true }
            ctrl && k == Key.S -> { a.save(); true }
            ctrl && k == Key.C -> { a.copy(); true }
            ctrl && k == Key.V -> { a.paste(); true }
            ctrl && k == Key.X -> { a.cut(); true }
            ctrl && k == Key.F -> { a.find(); true }
            ctrl && k == Key.H -> { a.replace(); true }
            ctrl && k == Key.B -> { a.toggleSidebar(); true }
            ctrl && k == Key.Slash -> { a.toggleComment(); true }
            ctrl && k == Key.D -> { a.duplicateLine(); true }
            ctrl && k == Key.L -> { a.selectLine(); true }
            ctrl && k == Key.G -> { a.goToLine(); true }
            ctrl && k == Key.N -> { a.newTab(); true }
            ctrl && k == Key.O -> { a.openFile(); true }
            ctrl && k == Key.W -> { a.closeTab(); true }
            k == Key.F3 -> { a.findNext(); true }
            k == Key.Escape -> a.escape()
            k == Key.Tab -> { if (shift) a.outdent() else a.indent(); true }
            else -> false
        }
    }
}
