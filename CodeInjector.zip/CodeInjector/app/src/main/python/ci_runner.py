# -*- coding: utf-8 -*-
"""Ponte Kotlin <-> CPython (Chaquopy): executa scripts com stdout/stderr/stdin em tempo real e analisa código."""
import ast
import builtins
import difflib
import gc
import json
import keyword
import linecache
import os
import queue
import sys
import threading
import time
import traceback
import types

_real_sleep = time.sleep
_state = {"tid": None, "stop": False, "stdin": queue.Queue()}
_sink = None
_BUILTIN_NAMES = set(dir(builtins)) | {
    "exit", "quit", "copyright", "credits", "license", "help",
    "__file__", "__name__", "__doc__", "__builtins__", "__spec__",
    "__loader__", "__package__", "__class__", "__debug__",
}


# ------------------------------------------------------------------ streams
class _Out:
    encoding = "utf-8"
    errors = "replace"

    def __init__(self, name):
        self._name = name

    def write(self, s):
        if not isinstance(s, str):
            s = str(s)
        if s:
            _sink.write(self._name, s)
        return len(s)

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True

    def fileno(self):
        raise OSError("fileno() não suportado")


class _In:
    encoding = "utf-8"

    def __init__(self):
        self._eof = False
        self._buf = ""

    def _fetch(self, prompt=""):
        """Bloqueia até o usuário enviar uma linha. Retorna a linha com '\\n' ou '' no EOF."""
        if self._eof:
            return ""
        _sink.onInputRequested(str(prompt))
        while True:
            if _state["stop"]:
                raise KeyboardInterrupt
            try:
                item = _state["stdin"].get(timeout=0.1)
                break
            except queue.Empty:
                continue
        if _state["stop"]:
            raise KeyboardInterrupt
        _sink.onInputConsumed()
        if item is None:
            self._eof = True
            return ""
        return item + "\n"

    def readline(self, size=-1):
        line = self._buf or self._fetch()
        self._buf = ""
        if size is not None and size >= 0 and len(line) > size:
            self._buf = line[size:]
            line = line[:size]
        return line

    def read(self, size=-1):
        if size is None or size < 0:
            parts = [self._buf]
            self._buf = ""
            while True:
                l = self._fetch()
                if not l:
                    break
                parts.append(l)
            return "".join(parts)
        while len(self._buf) < size:
            l = self._fetch()
            if not l:
                break
            self._buf += l
        out, self._buf = self._buf[:size], self._buf[size:]
        return out

    def readlines(self, hint=-1):
        return list(self)

    def __iter__(self):
        return self

    def __next__(self):
        l = self.readline()
        if not l:
            raise StopIteration
        return l

    def isatty(self):
        return False

    def readable(self):
        return True

    def fileno(self):
        raise OSError("fileno() não suportado")


_stdin_obj = _In()


def _input(prompt=""):
    if prompt:
        sys.stdout.write(str(prompt))
    line = _stdin_obj._fetch(prompt)
    if not line:
        raise EOFError("EOF when reading a line")
    return line.rstrip("\n")


def _sleep(secs):
    end = time.monotonic() + secs
    while True:
        if _state["stop"]:
            raise KeyboardInterrupt
        left = end - time.monotonic()
        if left <= 0:
            return
        _real_sleep(min(left, 0.05))


# ------------------------------------------------------------------ controle
def provide_input(text):
    _state["stdin"].put(text)


def provide_eof():
    _state["stdin"].put(None)


def stop():
    """Pede a interrupção: seta a flag e injeta KeyboardInterrupt na thread do script."""
    _state["stop"] = True
    tid = _state["tid"]
    if tid is None:
        return False
    import ctypes
    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(tid), ctypes.py_object(KeyboardInterrupt))
    return True


def _exit_code(e):
    c = e.code
    if c is None:
        return 0
    if isinstance(c, int):
        return c
    sys.stderr.write(str(c) + "\n")
    return 1


def _suggest(name, pool):
    low = name.lower()
    for c in pool:
        if c != name and c.lower() == low:
            return c
    m = difflib.get_close_matches(name, [c for c in pool if not c.startswith("__")], n=1, cutoff=0.75)
    return m[0] if m else ""


def _report_syntax(e, filename):
    sys.stderr.write("".join(traceback.format_exception_only(type(e), e)))
    _sink.onException(type(e).__name__, e.msg or "", e.lineno or 1, e.offset or 1, "")


def _report_exception(e, filename, g):
    tb = e.__traceback__
    while tb is not None and tb.tb_frame.f_code.co_filename == _THIS:
        tb = tb.tb_next
    line = -1
    t = tb
    while t is not None:
        if t.tb_frame.f_code.co_filename == filename:
            line = t.tb_lineno
        t = t.tb_next
    sys.stderr.write("".join(traceback.format_exception(type(e), e, tb)))
    sug = ""
    if isinstance(e, NameError) and getattr(e, "name", None):
        pool = set(g.keys()) | _BUILTIN_NAMES | set(keyword.kwlist)
        sug = _suggest(e.name, sorted(pool))
        if sug:
            sys.stderr.write("Você quis dizer: '%s'?\n" % sug)
    _sink.onException(type(e).__name__, str(e), line, 0, sug)


def run(source, filename, sink, workdir):
    """Executa o script. Retorna o código de saída."""
    global _sink
    _sink = sink
    _state["tid"] = threading.get_ident()
    _state["stop"] = False
    while not _state["stdin"].empty():
        try:
            _state["stdin"].get_nowait()
        except queue.Empty:
            break
    _stdin_obj._eof = False
    _stdin_obj._buf = ""

    os.makedirs(workdir, exist_ok=True)
    os.chdir(workdir)
    if workdir not in sys.path:
        sys.path.insert(0, workdir)
    import importlib
    importlib.invalidate_caches()

    before_modules = set(sys.modules)
    old = (sys.stdout, sys.stderr, sys.stdin, builtins.input, time.sleep, sys.argv, sys.modules.get("__main__"))
    sys.stdout, sys.stderr, sys.stdin = _Out("out"), _Out("err"), _stdin_obj
    builtins.input = _input
    time.sleep = _sleep
    sys.argv = [filename]
    linecache.cache[filename] = (len(source), None, source.splitlines(True), filename)

    main = types.ModuleType("__main__")
    main.__file__ = filename
    sys.modules["__main__"] = main
    g = main.__dict__
    code = 0
    try:
        try:
            compiled = compile(source, filename, "exec")
        except SyntaxError as e:
            _report_syntax(e, filename)
            return 1
        exec(compiled, g)
    except SystemExit as e:
        code = _exit_code(e)
    except KeyboardInterrupt:
        sys.stderr.write("\n[execução interrompida]\n")
        code = 130
    except BaseException as e:
        code = 1
        _report_exception(e, filename, g)
    finally:
        sys.stdout, sys.stderr, sys.stdin, builtins.input, time.sleep, sys.argv = old[:6]
        if old[6] is not None:
            sys.modules["__main__"] = old[6]
        # descarta módulos do workdir para que a próxima execução releia arquivos editados
        for name in set(sys.modules) - before_modules:
            f = getattr(sys.modules.get(name), "__file__", None)
            if f and str(f).startswith(workdir):
                sys.modules.pop(name, None)
        linecache.cache.pop(filename, None)
        _state["tid"] = None
        g.clear()
        gc.collect()
    return code


# ------------------------------------------------------------------ análise estática
def _ccol(lines, lineno, byte_off):
    try:
        s = lines[lineno - 1]
        return len(s.encode("utf-8")[:byte_off].decode("utf-8", "ignore")) + 1
    except Exception:
        return byte_off + 1


def _syntax_issue(e):
    line = e.lineno or 1
    col = max(e.offset or 1, 1)
    end_line = getattr(e, "end_lineno", None) or line
    end_col = getattr(e, "end_offset", None) or (col + 1)
    return {"kind": "syntax", "type": type(e).__name__, "msg": e.msg or "invalid syntax",
            "line": line, "col": col, "end_line": end_line, "end_col": max(end_col, col), "suggest": ""}


def _undefined_names(tree, source):
    bound = set(_BUILTIN_NAMES)
    star = False
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            bound.add(n.id)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound.add(n.name)
        elif isinstance(n, ast.arg):
            bound.add(n.arg)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                if a.name == "*":
                    star = True
                else:
                    bound.add((a.asname or a.name).split(".")[0])
        elif isinstance(n, ast.ExceptHandler) and n.name:
            bound.add(n.name)
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            bound.update(n.names)
        else:
            cn = n.__class__.__name__
            if cn in ("MatchAs", "MatchStar") and getattr(n, "name", None):
                bound.add(n.name)
            elif cn == "MatchMapping" and getattr(n, "rest", None):
                bound.add(n.rest)
    if star:
        return []
    lines = source.split("\n")
    pool = sorted(bound | set(keyword.kwlist))
    out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in bound:
            el = getattr(n, "end_lineno", None) or n.lineno
            out.append({"kind": "name", "type": "NameError", "msg": "name '%s' is not defined" % n.id,
                        "line": n.lineno, "col": _ccol(lines, n.lineno, n.col_offset),
                        "end_line": el, "end_col": _ccol(lines, el, getattr(n, "end_col_offset", n.col_offset + len(n.id))),
                        "suggest": _suggest(n.id, pool)})
            if len(out) >= 60:
                break
    out.sort(key=lambda d: (d["line"], d["col"]))
    return out


def check(source, filename="<editor>"):
    """Retorna JSON com os problemas: erro de sintaxe (CPython real) ou nomes não definidos."""
    try:
        compile(source, filename, "exec")
    except SyntaxError as e:
        return json.dumps([_syntax_issue(e)])
    except (ValueError, RecursionError, MemoryError, OverflowError):
        return "[]"
    try:
        tree = ast.parse(source, filename)
        return json.dumps(_undefined_names(tree, source))
    except Exception:
        return "[]"


_THIS = run.__code__.co_filename
