#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
command -v kotlinc >/dev/null 2>&1 || { echo "kotlinc not found; install Kotlin compiler to run this optional test." >&2; exit 2; }
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc "$ROOT/app/src/main/java/com/dev/codeinjector/PythonFrameworkDetector.kt" "$ROOT/tests/PythonFrameworkDetectorTest.kt" -include-runtime -d "$OUT/detector-tests.jar"
java -jar "$OUT/detector-tests.jar"
