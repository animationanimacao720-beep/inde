#!/usr/bin/env python3
"""Static sanity checks for the CodeInjector source tree; not a substitute for Android build/device tests."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(condition, message):
    if not condition:
        errors.append(message)

manifest = ROOT / 'app/src/main/AndroidManifest.xml'
try:
    tree = ET.parse(manifest)
    root = tree.getroot()
    ns = '{http://schemas.android.com/apk/res/android}'
    perms = {p.attrib.get(ns + 'name') for p in root.findall('uses-permission')}
    require('android.permission.INTERNET' in perms, 'Manifest missing INTERNET permission')
    require('com.termux.permission.RUN_COMMAND' in perms, 'Manifest missing Termux RUN_COMMAND permission')
    package_queries = {p.attrib.get(ns + 'name') for p in root.findall('./queries/package')}
    require('com.termux' in package_queries, 'Manifest missing package visibility for Termux')
    require('com.termux.x11' in package_queries, 'Manifest missing package visibility for Termux:X11')
except Exception as exc:
    errors.append(f'Manifest XML parse failed: {exc}')

required_files = [
    'app/src/main/java/com/dev/codeinjector/TermuxX11Runner.kt',
    'app/src/main/java/com/dev/codeinjector/TermuxCommandResultReceiver.kt',
    'app/src/main/java/com/dev/codeinjector/PythonFrameworkDetector.kt',
    'tests/PythonFrameworkDetectorTest.kt',
    'tools/run_detector_tests.sh',
    'app/src/main/java/com/dev/codeinjector/GitHubRepoImporter.kt',
    'app/src/main/java/com/dev/codeinjector/PyRunner.kt',
    'app/src/main/java/com/dev/codeinjector/CodeEditorScreen.kt',
    'app/src/main/python/ci_runner.py',
    'docs/TERMUX_X11_SETUP.md',
]
for rel in required_files:
    require((ROOT / rel).is_file(), f'Missing required file: {rel}')

runner = (ROOT / 'app/src/main/java/com/dev/codeinjector/TermuxX11Runner.kt').read_text()
py_runner = (ROOT / 'app/src/main/java/com/dev/codeinjector/PyRunner.kt').read_text()
ui = (ROOT / 'app/src/main/java/com/dev/codeinjector/CodeEditorScreen.kt').read_text()
receiver = (ROOT / 'app/src/main/java/com/dev/codeinjector/TermuxCommandResultReceiver.kt').read_text()
require('fun detectFramework' in runner, 'Framework detection function missing')
require('com.termux.RUN_COMMAND' in runner, 'Termux RUN_COMMAND action missing')
require('SDL_VIDEODRIVER=x11' in runner, 'SDL X11 environment missing')
require('export DISPLAY=:1' in runner, 'Runner does not use the documented X11 display :1')
require('CODEINJECTOR_PROOT_DISTRO' in runner, 'Optional proot-distro backend missing')
require('importlib.util.find_spec' in runner, 'Runner does not preflight the requested framework module')
require('fun stop(' in runner, 'External process stop function missing')
require('MAX_ARCHIVE_BYTES = 160 * 1024' in runner, 'Intent payload size guard missing')
require("pgrep -f '[t]ermux-x11 :1'" in runner, 'X11 display :1 startup verification missing')
require('termux-x11 :1 -legacy-drawing' in runner, 'X11 legacy drawing fallback missing')
require('termux-x11.log' in runner, 'X11 startup diagnostics log missing')
require('termux-x11-legacy.log' in runner, 'X11 legacy-mode diagnostics log missing')
require('python3-kivy' in runner and 'python3-pygame' in runner, 'Distro installer does not map graphical frameworks to system packages')
require('ci-proot-runner.sh' in runner, 'Proot runner wrapper missing')
require('detectFramework(source)' in py_runner, 'Execution path does not detect current source')
require("substringAfterLast('.').uppercase() in acceptedNames" in receiver, 'Result receiver does not match exact result keys')
require('Cancelando a inicialização' in py_runner, 'Startup stop race handling missing')
require('GitHubRepoImporter.importPublicRepo' in ui, 'GitHub import UI is not wired')
require('installPythonPackage' in ui, 'Package manager UI is not wired')
require('Importar projeto do GitHub' in ui, 'GitHub import UI text missing')

if errors:
    print('STATIC CHECKS: FAILED')
    for error in errors:
        print(' -', error)
    sys.exit(1)
print('STATIC CHECKS: PASS')
print(f'Checked manifest and {len(required_files)} required files plus integration markers.')
print('This script does not compile Kotlin/Gradle or run the app on Android.')
