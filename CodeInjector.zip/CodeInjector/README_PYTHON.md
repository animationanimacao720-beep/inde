# CodeInjector — IDE Python (Chaquopy)

## O que mudou
- Removidos: JavaRunner, TermuxRunner, CodeRunner (JS/Judge0), Pyodide/WebView, ecj/r8, preview HTML/JS, multi-linguagem.
- Novo: `PyRunner` (CPython via Chaquopy), `SyntaxAnalyzer` (CPython `compile()` + scanner rápido),
  `KeyboardSuggestionBar`, `FileExplorerSidebar`, `CodeEditorScreen` reescrito, `app/src/main/python/ci_runner.py`.
- Mantidos: `TextInjectorService` (injeção/sync com o CodeAssist), `Session`, `Project` (SAF), `KeyBindingHandler`.

## Atalhos (teclado físico)
Ctrl+R / F5 rodar · Shift+F5 / Ctrl+. parar · Ctrl+S salvar · Ctrl+F buscar · Ctrl+H substituir · Ctrl+B painel de arquivos
Ctrl+/ comentar · Ctrl+D duplicar linha · Alt+↑/↓ mover linha · Ctrl+G ir p/ linha · Ctrl+N/W/O aba nova/fechar/abrir

## Fontes
JetBrains Mono já vem em `app/src/main/assets/fonts/`. Para Fira Code, coloque `FiraCode-Regular.ttf` na mesma pasta
(o app detecta sozinho; menu ⋮ → Fonte).

## Build
Chaquopy é um plugin do Gradle: compile com Android Studio / Gradle (não só com o build interno do CodeAssist).
Python 3.11 no PATH do PC de build é opcional (só gera .pyc; sem ele o build segue com aviso).
Arquivos lidos/gravados pelos scripts ficam em `files/py_workspace` (as abas .py abertas são copiadas para lá para `import` funcionar).

## Como gerar o APK (Gradle)
**GitHub Actions (só pelo celular):** crie um repositório, envie esta pasta (a raiz do repo deve conter `settings.gradle.kts`),
abra a aba Actions → "Build APK" → Run workflow → baixe o artefato `CodeInjector-debug-apk` e instale.
**Android Studio:** File → Open na pasta, aguarde o sync e rode `assembleDebug` (precisa de JDK 17 e SDK 34).
