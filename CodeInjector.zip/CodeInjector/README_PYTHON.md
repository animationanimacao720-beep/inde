# CodeInjector — IDE Python (Chaquopy)

## O que mudou
- Removidos: JavaRunner, TermuxRunner, CodeRunner (JS/Judge0), Pyodide/WebView, ecj/r8, preview HTML/JS, multi-linguagem.
- Novo: `PyRunner` (CPython via Chaquopy), `SyntaxAnalyzer` (CPython `compile()` + scanner rápido),
  `KeyboardSuggestionBar`, `FileExplorerSidebar`, `CodeEditorScreen` reescrito, `app/src/main/python/ci_runner.py`.
- Removidos também: `TextInjectorService`, serviço de acessibilidade, injeção de texto e sincronização/atalho do CodeAssist.
- Mantidos: `Session`, `Project` (SAF), `KeyBindingHandler`, snippets.
- Novidades: botão executar flutuante (menu ⋮), "↻ Repetir" no console, barra inferior só com tab, desfazer/refazer, setas, copiar e colar, guias de indentação (estilo Godot, ligam/desligam no menu ⋮), indentação só com tabs, seleção por arrasto e botões Tudo/Cortar/Apagar, e gerenciador de arquivos em árvore (arraste da borda esquerda ou toque em ☰).

## Atalhos (teclado físico)
Ctrl+R / Ctrl+Enter / F5 rodar · Shift+F5 / Ctrl+. parar · Ctrl+S salvar · Ctrl+Shift+S salvar como
Ctrl+F buscar · Ctrl+H substituir · F3 próximo resultado · Ctrl+B painel de arquivos · Ctrl+Shift+P paleta de comandos
Ctrl+/ comentar · Ctrl+D duplicar linha · Alt+↑/↓ mover linha · Ctrl+G ir para linha · Ctrl+N/W/O nova aba/fechar/abrir

## Modo PC (teclado + mouse)
- Menu ⋮ → **Ativar modo PC (teclado + mouse)**: gira a tela para paisagem e prioriza o editor, sem a barra de sugestões de toque nem o botão flutuante de execução.
- Desative pelo mesmo menu para voltar à orientação automática do aparelho.
- Os principais atalhos (salvar, executar, abrir, abas, buscar e arquivos) funcionam mesmo quando o foco está fora do editor.
- `Ctrl+Shift+P` abre a paleta de comandos; use setas/Tab e Enter ou clique com o mouse. Os botões têm área de clique maior e contorno quando recebem foco do teclado.
- O modo PC não precisa de monitor, DeX ou computador: o próprio celular continua sendo a tela da IDE.

## Fontes
JetBrains Mono já vem em `app/src/main/assets/fonts/`. Para Fira Code, coloque `FiraCode-Regular.ttf` na mesma pasta
(o app detecta sozinho; menu ⋮ → Fonte).

## Build
Chaquopy é um plugin do Gradle: compile com Android Studio / Gradle (não só com o build interno do CodeAssist).
Python 3.11 no PATH do PC de build é opcional (só gera .pyc; sem ele o build segue com aviso).
Arquivos lidos/gravados pelos scripts ficam em `files/py_workspace` (as abas .py abertas são copiadas para lá para `import` funcionar).

## Como gerar o APK (Gradle)
**GitHub Actions (só pelo celular):** crie um repositório, envie esta pasta (a raiz do repo deve conter `settings.gradle.kts`),
abra a aba Actions → "Build APK" → Run workflow → baixe o artefato `CodeInjector-debug-apk` e instale.
**Android Studio:** File → Open na pasta, aguarde o sync e rode `assembleDebug` (precisa de JDK 17 e SDK 34).

## Novidades (v2.1)
- Console: Copiar, Limpar, ↻ Repetir, cores ANSI, tempo de execução e código de saída.
- Buscar no projeto e Símbolos (funções/classes) no menu ⋮.
- Dobrar blocos (seta no gutter) e breakpoints (toque no número da linha) com depurador simples: Continuar / Passo / variáveis.
- Linter com avisos amarelos: import e variável local não usados.
- Marcadores de tab (→), guias de indentação, indentação só com tabs.
- "Abrir com" para .py/texto de outros apps e Compartilhar.
- Entradas prontas para input() (menu ⋮).
- Biblioteca `requests` incluída (pip no build.gradle.kts; descomente numpy se quiser, mas o APK fica bem maior).

## Novidades (v2.2)
- Auto-completar de membros depois do ponto (`texto.`, `lista.`, `os.`, `self.`, objetos das suas classes), inferido do próprio código.
- Terminal Python (REPL) no console: botão "Terminal"; mantém variáveis entre comandos; blocos terminam com linha em branco.
  Com o terminal ligado, as variáveis do último script rodado ficam disponíveis nele (como `python -i`).

## Novidades do pacote de interface PC
- Modo PC opcional com orientação horizontal, indicação de atalhos e controles mais adequados a teclado/mouse.
- Paleta de comandos em `Ctrl+Shift+P` e atalhos globais de aplicação.
- Removidos os arquivos residuais do serviço de acessibilidade que não eram usados pela IDE.
